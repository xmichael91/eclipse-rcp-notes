package my.app;

import org.eclipse.equinox.app.IApplication;
import org.eclipse.equinox.app.IApplicationContext;

public class Application implements IApplication
{

	@Override
	public Object start(IApplicationContext a_context) throws Exception
	{
		String[] args = (String[]) a_context.getArguments().get(IApplicationContext.APPLICATION_ARGS);
		String userName = args[0];
		System.out.println("Привет, " + userName);
		
		return 0;
	}

	@Override
	public void stop()
	{
		// TODO Auto-generated method stub

	}

}
